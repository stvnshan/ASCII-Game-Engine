#ifndef MOVEMENTTYPE_H
#define MOVEMENTTYPE_H


enum MovementType { STRAIGHT, CYCLE, GRAVITY, PC};

#endif

