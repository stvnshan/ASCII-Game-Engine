#include "triple.h"

Triple::Triple(int x0,int y0, char ch0){
    x = x0;
    y = y0;
    ch = ch0;
}

