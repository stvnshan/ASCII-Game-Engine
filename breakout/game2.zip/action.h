#ifndef ACTION_H
#define ACTION_H

enum Action { INVALID = 0, UP, RIGHT, DOWN, LEFT, W, A, S, D, NONE,INVALIDD};

#endif

