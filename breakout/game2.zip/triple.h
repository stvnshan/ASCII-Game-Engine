#ifndef TRIPLE_H
#define TRIPLE_H

struct Triple
{
    int x;
    int y;
    char ch;
    //Triple();
    Triple(int, int , char);
};



#endif



