#ifndef STATE_H
#define STATE_H


enum State { EMPTY = 0, WALL, E, PLAYER, FOG, BALL};

#endif


