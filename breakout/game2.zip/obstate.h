#ifndef OBSTATE_H
#define OBSTATE_H


enum ObState { NORMAL = 0};

#endif



