#ifndef GAMESTATE_H
#define GAMESTATE_H

enum GameState { WIN , LOSE, ONGOING};
#endif

