#ifndef COLOR_H
#define COLOR_H

enum Color { GREEN, BLUE, WHITE,RED,CYAN};

#endif

