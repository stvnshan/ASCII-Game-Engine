#include "controller.h"

Action Controller::getAction(){
  return action(); 
}
